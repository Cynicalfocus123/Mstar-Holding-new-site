(function(){let e=document.createElement(`link`).relList;if(e&&e.supports&&e.supports(`modulepreload`))return;for(let e of document.querySelectorAll(`link[rel="modulepreload"]`))n(e);new MutationObserver(e=>{for(let t of e)if(t.type===`childList`)for(let e of t.addedNodes)e.tagName===`LINK`&&e.rel===`modulepreload`&&n(e)}).observe(document,{childList:!0,subtree:!0});function t(e){let t={};return e.integrity&&(t.integrity=e.integrity),e.referrerPolicy&&(t.referrerPolicy=e.referrerPolicy),e.crossOrigin===`use-credentials`?t.credentials=`include`:e.crossOrigin===`anonymous`?t.credentials=`omit`:t.credentials=`same-origin`,t}function n(e){if(e.ep)return;e.ep=!0;let n=t(e);fetch(e.href,n)}})();var e=[{category:`Defense`,title:`Thailand Defense Giant Mstar Defense Lands Major Contract, Expands Across Asia and Africa Ahead of $2.9B IPO`,date:`January 26, 2026`,dateSort:`2026-01-26`,source:`The Frontier Report`,excerpt:`Mstar Defense is reported to have secured a major defense contract covering armored vehicles, military communication systems, advanced R&D weapons, anti-drone weaponry, and ammunition while expanding across Asia and Africa.`,image:`media/news/mstar-defense-major-contract-asia-africa-ipo.webp`,slug:`mstar-defense-major-contract-asia-africa-ipo`,url:`https://thefrontierreport.com/thailand-defense-giant-mstar-defense-lands-major-contract-expands-across-asia-and-africa-ahead-of-2-9b-ipo/`,body:[{heading:`Strengthening Thailand's Defense Industry`,text:`The article reports that Mstar Defense, under Mstar Asia Co. Ltd, is expanding its role in Thailand's defense manufacturing sector through advanced manufacturing, research and development, and vertically integrated production capabilities.`},{heading:`Strategic Expansion Across Asia and Africa`,text:`The report highlights the company's regional expansion across Asia and Africa, positioning Mstar Defense closer to key defense markets and long-term government and institutional partners.`},{heading:`Building Momentum Ahead of IPO`,text:`The article describes how contract wins, regional market access, diversified product lines, and vertical integration support the company's positioning ahead of a planned $2.9 billion IPO.`},{heading:`Regional Security and Long-Term Vision`,text:`The report also notes Mstar Defense's ongoing international order fulfillment across the Middle East and Europe, emphasizing delivery capability, operational discipline, and long-term defense partnerships.`}],isPlaceholder:!1},{category:`Defense`,title:`Pasit Viwatkurkul: Shaping the Future of Warfare Entrepreneurship`,date:`April 23, 2024`,dateSort:`2024-04-23`,source:`CEOWORLD Magazine`,excerpt:`Pasit Viwatkurkul is highlighted for his vision in defense entrepreneurship, focusing on logistics, development systems, strategic partnerships, and support solutions for governments navigating a rapidly evolving global defense landscape.`,image:`media/news/pasit-viwatkurkul-future-of-warfare-entrepreneurship.webp`,slug:`pasit-viwatkurkul-future-of-warfare-entrepreneurship`,url:`https://ceoworld.biz/2024/04/23/pasit-viwatkurkul-shaping-the-future-of-warfare-entrepreneurship/`,body:[{heading:`A Broader Security Landscape`,text:`Modern security challenges now extend beyond conventional defense into cyber threats, space systems, autonomous tools, and AI-driven decision-making. The article frames this shift as a moment that requires builders who understand both emerging technology and the practical realities of national defense.`},{heading:`Defense Entrepreneurship With Practical Support`,text:`Pasit Viwatkurkul's vision centers on helping governments and institutions access defense hardware, logistics capabilities, development systems, and long-term support services. The emphasis is on practical solutions that can adapt as regional and global security needs change.`},{heading:`Partnerships, Funding, And Navigation`,text:`The defense sector requires more than technical ambition. Strategic partnerships, patient funding, and careful navigation of legal, procurement, and government roadblocks are essential for companies working in sensitive security markets.`},{heading:`Responsible Growth In A Competitive Sector`,text:`Modern defense companies face pressure from rapid technological change, proliferation risks, budget constraints, and international competition. Mstar Defense's role is presented around innovation, responsible partnerships, and sustainable growth within a complex industry.`}],isPlaceholder:!1},{category:`Founder Profile`,title:`Leap of Faith: Inside the Pioneering Mind of Pasit "Joe" Viwatkurkul`,date:`November 23, 2022`,dateSort:`2022-11-23`,source:`Prestige Thailand`,excerpt:`A profile on Pasit "Joe" Viwatkurkul, his entrepreneurial journey, Obaki, and his role in building technology ventures under the Mstar Holding ecosystem.`,image:`media/news/pasit-joe-viwatkurkul-profile.webp`,slug:`leap-of-faith-pasit-joe-viwatkurkul`,url:`https://www.prestigeonline.com/th/people/leap-of-faith-inside-the-pioneering-mind-of-pasit-joe-viwatkurkul/`,body:[{heading:`Early Startup Grit`,text:`The profile follows Pasit "Joe" Viwatkurkul through an entrepreneurial path shaped by experimentation, resilience, and a willingness to build before conditions are perfect.`},{heading:`Music Freelancer And Building Momentum`,text:`His early work with Music Freelancer reflects the hands-on reality of startup building: finding a market, refining the product, learning from pressure, and continuing forward with discipline.`},{heading:`Obaki And Connected Communities`,text:`Obaki is presented as a platform concept connecting cooks, farmers, hosts, and customers. The idea reflects a broader interest in technology that links communities and helps people create new economic opportunities.`},{heading:`Technology, Mentoring, And Impact`,text:`Within the Mstar ecosystem, Pasit's work connects venture building with mentorship and technology-led impact. The article positions him as a builder focused on useful platforms, people, and long-term value.`}],isPlaceholder:!1},{category:`Leadership`,title:`CEO Spotlight: Jakapun Viwatkurkul, CEO and President of Mstar Holding`,date:`March 1, 2022`,dateSort:`2022-03-01`,source:`CEOWORLD Magazine`,excerpt:`Jakapun Viwatkurkul discusses Mstar Holding's multi-sector growth, expansion strategy, and approach to investing across technology, food, real estate, eCommerce, and regional markets.`,image:`media/news/jakapun-viwatkurkul-ceo-spotlight.webp`,slug:`ceo-spotlight-jakapun-viwatkurkul`,url:`https://ceoworld.biz/2022/03/01/ceo-spotlight-jakapun-viwatkurkul-ceo-and-president-of-mstar-holding/`,body:[{heading:`CEO And President Of A Multi-Sector Group`,text:`Jakapun Viwatkurkul is profiled in his role guiding Mstar Holding across multiple sectors, balancing operational leadership with long-term portfolio development.`},{heading:`Regional Expansion Focus`,text:`The article highlights expansion ambitions across the UAE, Thailand, India, and surrounding regional markets. The strategy connects local operating experience with broader international opportunity.`},{heading:`Growth Across Core Sectors`,text:`Mstar Holding's roadmap includes technology, food, real estate, eCommerce, and investment. The focus is on building resilient businesses that can adapt across market cycles.`},{heading:`Adapting After COVID-19`,text:`The profile also discusses how the company thinks about recovery, adaptation, and strategic planning after COVID-19, with an emphasis on practical business lines and long-term positioning.`}],isPlaceholder:!1},{category:`Expansion`,title:`Mstar Holding's expansion will drive growth both in UAE and Thailand`,date:`January 27, 2022`,dateSort:`2022-01-27`,source:`Gulf News`,excerpt:`Mstar Holding outlines expansion plans connecting Thailand and the UAE, with focus areas including food, eCommerce, tourism, technology, import/export, and regional job creation.`,image:`media/news/mstar-holding-uae-thailand-expansion.webp`,slug:`mstar-holding-expansion-uae-thailand`,url:`https://gulfnews.com/business/corporate-news/mstar-holdings-expansion-will-drive-growth-both-in-uae-and-thailand-1.1643211933684`,body:[{heading:`A Thailand-UAE Business Bridge`,text:`The article presents Mstar Holding's expansion as a bridge between Thailand and Dubai, with the UAE positioned as a strategic base for broader Middle East growth.`},{heading:`Food, Tourism, Technology, And eCommerce`,text:`Mstar's growth areas include food, eCommerce, tourism, and technology, with concepts such as Obaki, Food at Home, and Ship2way tied to platform development and cross-border demand.`},{heading:`Import, Export, And Trading Opportunity`,text:`Import/export activity is framed as an important part of the group's expansion, connecting product movement, trading relationships, and regional market access.`},{heading:`Strategic Growth Across The Middle East`,text:`The article points to tourism and business development as part of a wider Middle East strategy, with Mstar seeking to connect operating companies and opportunities across markets.`}],isPlaceholder:!1},{category:`Technology`,title:`Mstar aims to help economic recovery from COVID-19`,date:`August 17, 2020`,dateSort:`2020-08-17`,source:`Forbes India`,excerpt:`Mstar Technology discusses digital tools designed to support farmers, workers, and communities affected by COVID-19 through job creation, direct buyer connections, and technology access.`,image:`media/news/mstar-economic-recovery-covid-19.webp`,slug:`mstar-economic-recovery-covid-19`,url:`https://www.forbesindia.com/article/brand-connect/mstar-aims-to-help-economic-recovery-from-covid-19/61705/1`,body:[{heading:`Supporting Communities After Disruption`,text:`The article focuses on Mstar Technology's efforts to support people affected by COVID-19, especially farmers, laid-off workers, and communities looking for practical ways to recover.`},{heading:`Direct Access For Farmers`,text:`Mstar's technology vision includes tools that help farmers sell, barter, and connect directly with buyers, reducing friction and opening access to more resilient local markets.`},{heading:`Freelance And Hometown Opportunity`,text:`The recovery effort also includes job and freelance concepts intended to help people find work in their hometowns instead of relying only on disrupted urban employment channels.`},{heading:`Technology As Access`,text:`Across the article, Mstar's mission is framed around helping people access opportunity through digital tools, community support, and practical economic participation.`}],isPlaceholder:!1}],t=[...e].sort((e,t)=>new Date(t.dateSort)-new Date(e.dateSort)),n=t=>e.find(e=>e.slug===t),r=document.querySelector(`[data-nav]`),i=document.querySelector(`[data-nav-toggle]`),a=document.querySelector(`[data-header]`),o=document.body.classList.contains(`business-page`)||document.body.classList.contains(`news-page`),s=e=>{r?.classList.toggle(`is-open`,e),i?.classList.toggle(`is-open`,e),i?.setAttribute(`aria-expanded`,String(e)),i?.setAttribute(`aria-label`,e?`Close navigation`:`Open navigation`),document.body.classList.toggle(`nav-open`,e)};i?.addEventListener(`click`,()=>{s(!r?.classList.contains(`is-open`))}),r?.addEventListener(`click`,e=>{e.target instanceof HTMLAnchorElement&&s(!1)});var c=()=>{a?.classList.toggle(`is-scrolled`,o||window.scrollY>24)};c(),window.addEventListener(`scroll`,c,{passive:!0});var l=window.matchMedia(`(prefers-reduced-motion: reduce)`).matches,u=()=>{let e=Math.min(window.innerWidth,window.innerHeight),t=Math.max(window.innerWidth,window.innerHeight),n=Math.min(window.screen.width,window.screen.height),r=Math.max(window.screen.width,window.screen.height),i=e<=480&&t<=932,a=n<=480&&r<=932,o=window.innerHeight>=window.innerWidth;return(i||a)&&o},d=document.querySelector(`[data-business-hero-video]`),f=()=>{if(!(d instanceof HTMLVideoElement))return;let e=d.dataset.desktopSrc,t=d.dataset.mobileSrc,n=u()?t:e,r=d.querySelector(`source`);if(!n||!(r instanceof HTMLSourceElement))return;let i=new URL(n,window.location.href).href;r.src!==i&&(r.src=n,d.load(),l||d.play().catch(()=>{}))},p=()=>{f(),requestAnimationFrame(f),window.setTimeout(f,160)};p(),window.addEventListener(`resize`,f),window.addEventListener(`orientationchange`,f),window.addEventListener(`pageshow`,p);var m=document.querySelector(`[data-business-sectors]`),h=document.querySelector(`[data-home-news-list]`),g=document.querySelector(`[data-news-grid]`),_=document.querySelector(`[data-news-detail]`),v=[{name:`Real Estate`,id:`real-estate`,headline:`Building Enduring Value`,description:`Strategic real estate development focused on long-term value, premium locations, and scalable regional growth.`,poster:`../media/hero-poster.webp`,companies:[{name:`Mstar Property`,description:`We develop affordable family homes to large-scale luxury mansion communities, creating quality residential projects designed for modern living, long-term value, and premium locations.`,mediaType:`video`,mediaSrc:`../videos/business-mstar-property.mp4`,poster:`../media/hero-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/mstar-property-logo.png`,logoAlt:`Mstar Property logo`},{name:`BuyHomeForLess`,description:`We offer a wide range of land, homes, and condos, from affordable properties to high-end real estate for sale, rent, and development opportunities.`,mediaType:`video`,mediaSrc:`../videos/business-buyhomeforless.mp4`,poster:`../media/operations-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/buyhomeforless-logo.png`,logoAlt:`BuyHomeForLess logo`},{name:`Senior Home`,description:`Asia and Thailand's leading senior care home developer, creating comfortable, affordable communities with spacious open-floor-plan designs tailored to the unique needs of seniors.`,mediaType:`video`,mediaSrc:`../videos/business-senior-home.mp4`,poster:`../media/growth-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/seniorcaring-logo.png`,logoAlt:`SeniorCaring.net logo`}]},{name:`Food & Hospitality`,id:`food-hospitality`,headline:`Elevating Experiences Every Day`,description:`Food and hospitality ventures designed around consumer demand, operational quality, and market expansion.`,poster:`../media/operations-poster.webp`,companies:[{name:`Foodonlines.com`,description:`We bring groceries to your door for less.`,mediaType:`video`,mediaSrc:`../videos/business-foodonlines-2.mp4`,poster:`../media/operations-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/foodonlines-logo.png`,logoAlt:`Foodonlines.com logo`},{name:`One Taste`,description:`One Taste provides ready-to-eat MRE meal solutions designed for military troops, emergency response, disaster relief, and remote operations where fast, reliable nutrition is essential.`,mediaType:`video`,mediaSrc:`../videos/business-one-taste.mp4`,poster:`../media/hero-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/one-taste-logo.png`,logoAlt:`One Taste logo`},{name:`Seniorhome.net`,description:`Hospitality-adjacent support designed around comfort, accessibility, and quality daily living.`,mediaType:`video`,mediaSrc:`../videos/business-hospitality-senior-home-care.mp4`,poster:`../media/growth-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/seniorcaring-logo.png`,logoAlt:`SeniorCaring.net logo`}]},{name:`Import / Export`,id:`import-export`,headline:`Connecting Markets, Creating Opportunities`,description:`Cross-border trade and supply operations supporting regional commerce, distribution, and international partnerships.`,poster:`../media/growth-poster.webp`,companies:[{name:`American Buying Service`,description:`Buying and sourcing support for cross-border commerce, distribution needs, and international partnerships.`,mediaType:`video`,mediaSrc:`../videos/business-american-buying-service.mp4`,poster:`../media/growth-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/american-buying-service-logo.png`,logoAlt:`American Buying Service logo`},{name:`ABS Fulfillment`,description:`Fulfillment operations supporting trade flows, practical logistics, and scalable distribution activity.`,mediaType:`video`,mediaSrc:`../videos/business-abs-fulfillment.mp4`,poster:`../media/operations-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/abs-fulfillment-logo.png`,logoAlt:`ABS Fulfillment logo`}]},{name:`Defense`,id:`defense`,headline:`Supporting Strategic Industry Growth`,description:`Defense-focused operations supporting manufacturing, technology development, and strategic industry partnerships.`,poster:`../media/hero-poster.webp`,companies:[{name:`Mstar Defense`,description:`Defense-focused operations supporting strategic industry partnerships, manufacturing, and technology development.`,mediaType:`video`,mediaSrc:`../videos/business-mstar-defense.mp4`,poster:`../media/hero-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/mstar-defense-logo.png`,logoAlt:`Mstar Defense logo`}]},{name:`E-commerce & Technology`,id:`ecommerce-technology`,headline:`Building Digital Platforms for Growth`,description:`Digital commerce and technology initiatives built to support scalable platforms, modern operations, and future-ready growth.`,poster:`../media/operations-poster.webp`,companies:[{name:`Foodonlines.com`,description:`Digital food commerce designed to support modern customer access, practical ordering, and market reach.`,mediaType:`video`,mediaSrc:`../videos/business-ecommerce-foodonlines.mp4`,poster:`../media/operations-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/foodonlines-logo.png`,logoAlt:`Foodonlines.com logo`},{name:`Hizoz.com`,description:`A digital platform initiative built around scalable technology, modern operations, and growth potential.`,mediaType:`video`,mediaSrc:`../videos/business-hizoz.mp4`,poster:`../media/growth-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/hizoz-logo.png`,logoAlt:`Hizoz.com logo`},{name:`Mstar Technology`,description:`Technology operations supporting platform development, digital infrastructure, and future-ready growth.`,mediaType:`video`,mediaSrc:`../videos/business-mstar-technology.mp4`,poster:`../media/hero-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/mstar-technology-logo.png`,logoAlt:`Mstar Technology logo`}]},{name:`Entertainment`,id:`entertainment`,headline:`Creating Destination Experiences`,description:`Entertainment ventures focused on destination experiences, media opportunities, events, and lifestyle-driven growth.`,poster:`../media/growth-poster.webp`,companies:[{name:`Boogoo Music Festival`,description:`Event-focused entertainment shaped around destination experiences, audiences, and lifestyle-driven growth.`,mediaType:`video`,mediaSrc:`../videos/business-boogoo.mp4`,poster:`../media/growth-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/boogoo-logo.png`,logoAlt:`Boogoo Music Festival logo`},{name:`Mstar Airsoft`,description:`Entertainment operations focused on active destination experiences, events, and audience engagement.`,mediaType:`video`,mediaSrc:`../videos/business-mstar-airsoft.mp4`,poster:`../media/hero-poster.webp`,ctaLabel:`View Company`,ctaHref:`#`,logo:`../media/logos/mstar-airsoft-logo.png`,logoAlt:`Mstar Airsoft logo`}]}],y=e=>String(e).replace(/[&<>"']/g,e=>({"&":`&amp;`,"<":`&lt;`,">":`&gt;`,'"':`&quot;`,"'":`&#39;`})[e]),b=e=>y(e).replaceAll(`E-commerce`,`E&#8209;commerce`),x=(e,t=``)=>/^(?:[a-z]+:)?\/\//i.test(e)||e.startsWith(`#`)?e:`${t}${e}`,S=(e,t,n={})=>{let r=n.assetPrefix||``,i=t===`home`?`home-news-card`:`news-article-card`,a=t===`home`?`home-news-card-media`:`news-article-media`,o=t===`home`?`home-news-card-body`:`news-article-body`,s=t===`home`?`home-news-pill`:`news-article-category`,c=t===`home`?`home-news-card-title`:`news-article-title`,l=t===`home`?`home-news-card-excerpt`:`news-article-excerpt`,u=t===`home`?`home-news-card-date`:`news-article-date`,d=t===`home`?`home-news-card-source`:`news-article-source`,f=t===`home`?`home-news-card-meta`:`news-article-meta`,p=t===`home`?`home-news-card-arrow`:`news-article-arrow`,m=t===`news`&&e.isPlaceholder?`<span class="news-placeholder-label">Placeholder article</span>`:``,h=e.source?`<span class="${d}">${y(e.source)}</span>`:``,g=`
      <span class="${a}">
        <img
          src="${y(x(e.image,r))}"
          alt=""
          loading="lazy"
          decoding="async"
        />
      </span>
      <span class="${o}">
        <span class="${s}">${y(e.category)}</span>
        <span class="${c}">${y(e.title)}</span>
        <span class="${l}">${y(e.excerpt)}</span>
        <span class="${f}">
          ${h}
          <span class="${u}">${y(e.date)}</span>
          ${m}
          <span class="${p}" aria-hidden="true"></span>
        </span>
      </span>
  `;return e.url?`
    <a
      class="${i}"
      href="${y(e.url)}"
      target="_blank"
      rel="noopener noreferrer"
    >
      ${g}
    </a>
  `:`<article class="${i}">${g}</article>`},C=()=>{h&&(h.innerHTML=t.slice(0,4).map(e=>S(e,`home`,{assetPrefix:h.dataset.newsAssetPrefix||``})).join(``)),g&&(g.innerHTML=t.map(e=>S(e,`news`,{assetPrefix:g.dataset.newsAssetPrefix||``})).join(``))},w=()=>{if(!_)return;let e=n(_.dataset.newsDetail||``),t=_.dataset.newsAssetPrefix||``,r=_.dataset.newsIndexHref||`../`;if(!e){_.innerHTML=`
      <section class="news-detail-page">
        <a class="news-detail-back" href="${y(r)}">Back to News and Media</a>
        <h1 class="news-detail-title">Article not found</h1>
      </section>
    `;return}let i=e.url?`
      <a
        class="news-detail-original"
        href="${y(e.url)}"
        target="_blank"
        rel="noopener noreferrer"
      >
        <span>Read original article</span>
        <span class="cta-arrow" aria-hidden="true"></span>
      </a>
    `:``,a=e.body.map(e=>`
        <section class="news-detail-body-section">
          <h2>${y(e.heading)}</h2>
          <p>${y(e.text)}</p>
        </section>
      `).join(``);_.innerHTML=`
    <article class="news-detail-page">
      <a class="news-detail-back" href="${y(r)}">Back to News and Media</a>
      <header class="news-detail-hero">
        <div class="news-detail-copy">
          <span class="news-detail-category">${y(e.category)}</span>
          <h1 class="news-detail-title">${y(e.title)}</h1>
          <p class="news-detail-excerpt">${y(e.excerpt)}</p>
          <div class="news-detail-meta">
            <span>${y(e.source)}</span>
            <span>${y(e.date)}</span>
          </div>
          ${i}
        </div>
        <figure class="news-detail-media">
          <img
            src="${y(x(e.image,t))}"
            alt="${y(e.title)}"
            loading="eager"
          />
        </figure>
      </header>
      <div class="news-detail-body">
        ${a}
      </div>
    </article>
  `},T=e=>{let t=`${e.name} media`,n=e.poster||e.mediaSrc;return e.mediaType===`video`?`
      <video
        class="company-media-video"
        autoplay
        muted
        loop
        playsinline
        preload="none"
        poster="${y(n)}"
        data-src="${y(e.mediaSrc)}"
        aria-label="${y(t)}"
      >
      </video>
    `:`<img src="${y(e.mediaSrc)}" alt="${y(t)}" loading="lazy" decoding="async" />`},E=e=>e.logo?`
    <img
      class="business-company-logo"
      src="${y(e.logo)}"
      alt="${y(e.logoAlt||`${e.name} logo`)}"
      loading="lazy"
      decoding="async"
    />
  `:``,D=e=>`
  <article class="company-block">
    <div class="company-copy">
      ${E(e)}
      <h3 class="business-company-title">${y(e.name)}</h3>
      <p>${y(e.description)}</p>
    </div>
    <div class="company-media">
      ${T(e)}
    </div>
    <div class="company-action">
      <a class="outline-cta dark-outline" href="${y(e.ctaHref)}">
        <span>${y(e.ctaLabel)}</span>
        <span class="cta-arrow" aria-hidden="true"></span>
      </a>
    </div>
  </article>
`,O=e=>{if(!(e instanceof HTMLVideoElement)||e.dataset.loaded===`true`)return;let t=e.dataset.src;if(!t)return;let n=document.createElement(`source`);n.src=t,n.type=`video/mp4`,e.append(n),e.dataset.loaded=`true`,e.load()},k=e=>{if(!(e instanceof HTMLVideoElement)||l)return;O(e);let t=()=>{e.play().catch(()=>{})};t(),requestAnimationFrame(t),window.setTimeout(t,250)};C(),w(),m&&(m.innerHTML=`
    <nav class="sector-nav" aria-label="Business sectors">${v.map(e=>`<a href="#${e.id}">${b(e.name)}</a>`).join(``)}</nav>
    ${v.map(e=>{let t=e.companies.map(D).join(``);return`
        <section
          class="sector-section business-sector business-sector-section"
          id="${e.id}"
          aria-label="${y(e.name)}"
        >
          <div class="sector-bg" aria-hidden="true">
            <img
              src="${y(e.poster)}"
              alt=""
              loading="lazy"
              decoding="async"
            />
          </div>
          <div class="business-sector-layout business-sector-grid">
            <div class="sector-copy sector-heading business-sector-sticky">
              <h2 class="sector-label business-sector-title">${b(e.name)}</h2>
            </div>
            <div class="company-list business-sector-companies">
              ${t}
            </div>
          </div>
        </section>
      `}).join(``)}
  `),((e=document)=>{if(!e)return;let t=Array.from(e.querySelectorAll(`.company-media-video`));if(!t.length)return;if(!(`IntersectionObserver`in window)){t.forEach(k);return}let n=new IntersectionObserver(e=>{e.forEach(e=>{e.isIntersecting&&(k(e.target),n.unobserve(e.target))})},{rootMargin:`450px 0px`,threshold:.01});t.forEach(e=>n.observe(e))})(m),l&&document.querySelectorAll(`video`).forEach(e=>{e.removeAttribute(`autoplay`),e.pause()});